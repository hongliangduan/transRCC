import deepsmiles
converter = deepsmiles.Converter(rings=True, branches=True)

files = ['dev', 'test', 'train']
for file in files:
    f1 = open(file+'.source', 'r')
    f2 = open(file+'.target', 'r')
    f3 = open('deep_'+file+'.source', 'w')
    f4 = open('deep_'+file+'.target', 'w')
    l1 = f1.readlines()
    l2 = f2.readlines()
    for i in range(len(l1)):
        rs = l1[i].split('>>')[0].split('.')
        p = l1[i].split('>>')[1].strip()
        deep_rs = []
        try:
            for r in rs:
                encoded = converter.encode(r)
                deep_rs.append(encoded)
            deep_p = converter.encode(p)
            deep_target = converter.encode(l2[i].strip())
            rxn = '.'.join(deep_rs)+'>>'+deep_p
            f3.write(rxn+'\n')
            f4.write(deep_target + '\n')
        except:
            print(l1[i])
            continue
