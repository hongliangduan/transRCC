# 将 smiles 转化为 smarts
# 并进行分词

from SmilesPE.pretokenizer import atomwise_tokenizer
from rdkit import Chem
import sys

fname = sys.argv[1]
fname_out = sys.argv[2]


def sl2st(sl: str) -> str:
    m = Chem.MolFromSmiles(sl)
    return ' '.join(atomwise_tokenizer(Chem.MolToSmarts(m)))


def inter2inter(inters: list) -> list:
    inters_st = []
    for i in inters:
        inters_st.append(sl2st(i))
    return inters_st


def reaction2reaction(reactions: list) -> list:
    reactions_st = list()
    for reaction in reactions:
        reactants, products = reaction.split('>>')
        reactants_st = list()
        for i in reactants.split('.'):
            reactants_st.append(sl2st(i))
        products_st = sl2st(products)
        reactions_st.append('.'.join(reactants_st) + ' >> ' + products_st)
    return reactions_st


def agg(reactions: list, inter1: list, inter2: list) -> list:
    lines = []
    for i, j, k in zip(reactions, inter1, inter2):
        lines.append('|||'.join([i, j, k]))
    return lines


reactions = []
inter1s = []
inter2s = []

with open(fname, 'r') as f:

    for lines in f:
        reaction, inter1, inter2 = lines.rstrip('\n').split('|||')
        reactions.append(reaction)
        inter1s.append(inter1)
        inter2s.append(inter2)
lines_st = agg(reaction2reaction(reactions),
               inter2inter(inter1s), inter2inter(inter2s))

with open(fname_out, 'w') as fo:
    for line in lines_st:
        fo.write(line)
        fo.write('\n')
