#!python

__version__ = "0.0.3"
__author__ = "zhaisilong"
__home_page__ = "https://zhaisilong.com"

# conda install rdkit
from rdkit.Chem import CanonSmiles, MolToSmarts, MolFromSmiles
# pip install SmilesPE
from SmilesPE.pretokenizer import atomwise_tokenizer
import re


def smi_canonize(smi: str) -> str:
    '''
    smiles 的正则化
    '''
    try:
        return CanonSmiles(smi, useChiral=1)
    except:
        print(f'{smi} 正则化失败')
        return None


def smi_tokenizer(smi: str) -> str:
    """
    Tokenize a SMILES molecule or reaction
    飞利浦的 moltransformer
    """
    pattern = "(\[[^\]]+]|Br?|Cl?|N|O|S|P|F|I|b|c|n|o|s|p|\(|\)|\.|=|#|-|\+|\\\\|\/|:|~|@|\?|>|\*|\$|\%[0-9]{2}|[0-9])"
    regex = re.compile(pattern)
    tokens = [token for token in regex.findall(smi)]
    assert smi == ''.join(tokens)
    return ' '.join(tokens)


def sl2st(sl: str) -> str:
    """
    将 smiles 字符串转化为 smarts 字符串
    """
    try:
        return MolToSmarts(MolFromSmiles(sl))
    except Exception as e:
        print(f"{sl} 转化为 smarts 字符串失败")
        print(e)
        return None


def get_list_from_file(fpath: str) -> list:
    """
    按行读取 txt 文件到字符串列表，无换行符
    """
    try:
        smiles = []
        with open(fpath, 'r') as f:
            for line in f:
                smiles.append(line.rstrip('\n'))
        return smiles
    except:
        return None


def write_list_to_file(smiles_list: list, fpath: str) -> None:
    """
    将 SMILES 字符串列表写入文件
    """
    with open(fpath, 'w') as f:
        for smi in smiles_list:
            f.write(smi)
            f.write('\n')


def get_pair(source: str, target: str) -> tuple:
    """
    pair source and target
    return source_list, target_list
    """
    smiles_s = get_smiles(fpath=source)
    smiles_t = get_smiles(fpath=target)
    return smiles_s, smiles_t


def canonize_list(smiles: list) -> list:
    c_smiles = []
    for smi in smiles:
        if (c := canonize(smi.rstrip('\n'))) is None:
            continue
        c_smiles.append(c)
    return c_smiles


def canonize_file(path_in: str, path_out: str = 'output.txt'):
    smiles = get_smiles(path_in)
    print(f"Befor canoized, smiles containes {len(smiles)} lines")
    c_smiles = canonize_list(smiles)
    write_smiles(c_smiles, path_out)
    print(f"after canoized, smiles containes {c_smiles} lines")


def tokenize_list(smis: list) -> list:
    invalid = 0
    tk_smis = []
    for smi in smis:
        if (t_s := tokenize(smi)) is None:
            invalid += 1
            continue
        tk_smis.append(t_s)
    print(f'{invalid} smiles found invalid when tokenizing')
    return tk_smis


def tokenize(smi: str) -> str:
    """
    只能用于分子，不能用于反应
    """
    try:
        return ' '.join(atomwise_tokenizer(smi))
    except:
        return None


if __name__ == '__main__':
    pass
#!python

__version__ = "0.0.3"
__author__ = "zhaisilong"
__home_page__ = "https://zhaisilong.com"

# conda install rdkit
# pip install SmilesPE


def smi_canonize(smi: str) -> str:
    '''
    smiles 的正则化
    '''
    try:
        return CanonSmiles(smi, useChiral=1)
    except:
        print(f'{smi} 正则化失败')
        return None


def smi_tokenizer(smi: str) -> str:
    """
    Tokenize a SMILES molecule or reaction
    飞利浦的 moltransformer
    """
    pattern = "(\[[^\]]+]|Br?|Cl?|N|O|S|P|F|I|b|c|n|o|s|p|\(|\)|\.|=|#|-|\+|\\\\|\/|:|~|@|\?|>|\*|\$|\%[0-9]{2}|[0-9])"
    regex = re.compile(pattern)
    tokens = [token for token in regex.findall(smi)]
    assert smi == ''.join(tokens)
    return ' '.join(tokens)


def sl2st(sl: str) -> str:
    """
    将 smiles 字符串转化为 smarts 字符串
    """
    try:
        return MolToSmarts(MolFromSmiles(sl))
    except Exception as e:
        print(f"{sl} 转化为 smarts 字符串失败")
        print(e)
        return None


def get_list_from_file(fpath: str) -> list:
    """
    按行读取 txt 文件到字符串列表，无换行符
    """
    try:
        smiles = []
        with open(fpath, 'r') as f:
            for line in f:
                smiles.append(line.rstrip('\n'))
        return smiles
    except:
        return None


def write_list_to_file(smiles_list: list, fpath: str) -> None:
    """
    将 SMILES 字符串列表写入文件
    """
    with open(fpath, 'w') as f:
        for smi in smiles_list:
            f.write(smi)
            f.write('\n')


def get_pair(source: str, target: str) -> tuple:
    """
    pair source and target
    return source_list, target_list
    """
    smiles_s = get_smiles(fpath=source)
    smiles_t = get_smiles(fpath=target)
    return smiles_s, smiles_t


def canonize_list(smiles: list) -> list:
    c_smiles = []
    for smi in smiles:
        if (c := canonize(smi.rstrip('\n'))) is None:
            continue
        c_smiles.append(c)
    return c_smiles


def canonize_file(path_in: str, path_out: str = 'output.txt'):
    smiles = get_smiles(path_in)
    print(f"Befor canoized, smiles containes {len(smiles)} lines")
    c_smiles = canonize_list(smiles)
    write_smiles(c_smiles, path_out)
    print(f"after canoized, smiles containes {c_smiles} lines")


def tokenize_list(smis: list) -> list:
    invalid = 0
    tk_smis = []
    for smi in smis:
        if (t_s := tokenize(smi)) is None:
            invalid += 1
            continue
        tk_smis.append(t_s)
    print(f'{invalid} smiles found invalid when tokenizing')
    return tk_smis


def tokenize(smi: str) -> str:
    """
    只能用于分子，不能用于反应
    """
    try:
        return ' '.join(atomwise_tokenizer(smi))
    except:
        return None


if __name__ == '__main__':
    pass
